export type Clip = {
  id: string
  start: number // grid column start (1-based units)
  span: number // width in grid units
  label: string
}

export type Track = {
  id: string
  name: string
  type: string
  color: string // tailwind bg class for clips
  border: string // tailwind border class
  clips: Clip[]
}

export const TRACKS: Track[] = [
  {
    id: 't1',
    name: 'Drums',
    type: 'Audio',
    color: 'bg-cyan-500/80',
    border: 'border-cyan-300/40',
    clips: [
      { id: 'c1', start: 1, span: 4, label: 'Kit_Loop' },
      { id: 'c2', start: 6, span: 6, label: 'Break_01' },
      { id: 'c3', start: 14, span: 3, label: 'Fill' },
    ],
  },
  {
    id: 't2',
    name: 'Bass',
    type: 'MIDI',
    color: 'bg-amber-500/80',
    border: 'border-amber-300/40',
    clips: [
      { id: 'c4', start: 2, span: 8, label: 'Sub_Bass' },
      { id: 'c5', start: 12, span: 5, label: 'Reese' },
    ],
  },
  {
    id: 't3',
    name: 'Synth Lead',
    type: 'MIDI',
    color: 'bg-emerald-500/80',
    border: 'border-emerald-300/40',
    clips: [
      { id: 'c6', start: 5, span: 5, label: 'Arp_A' },
      { id: 'c7', start: 11, span: 4, label: 'Lead_Hook' },
    ],
  },
  {
    id: 't4',
    name: 'Vocals',
    type: 'Audio',
    color: 'bg-rose-500/80',
    border: 'border-rose-300/40',
    clips: [
      { id: 'c8', start: 3, span: 6, label: 'Verse_Comp' },
      { id: 'c9', start: 10, span: 7, label: 'Chorus_Take3' },
    ],
  },
]

export type FileNode = {
  name: string
  children?: FileNode[]
}

export const FILE_TREE: FileNode[] = [
  {
    name: 'Project Audio',
    children: [
      { name: 'Drums', children: [{ name: 'Kit_Loop.wav' }, { name: 'Break_01.wav' }, { name: 'Fill.wav' }] },
      { name: 'Bass', children: [{ name: 'Sub_Bass.aif' }, { name: 'Reese.aif' }] },
      { name: 'Vocals', children: [{ name: 'Verse_Comp.wav' }, { name: 'Chorus_Take3.wav' }] },
    ],
  },
  {
    name: 'Samples',
    children: [
      { name: 'Foley', children: [{ name: 'Vinyl_Crackle.wav' }, { name: 'Tape_Stop.wav' }] },
      { name: 'One Shots', children: [{ name: 'Clap_909.wav' }, { name: 'Snare_Rim.wav' }] },
    ],
  },
  { name: 'Bounces', children: [{ name: 'Master_v3.wav' }, { name: 'Rough_Mix.mp3' }] },
]

export const INSERT_EFFECTS = [
  { id: 'fx1', name: 'EQ Eight', enabled: true },
  { id: 'fx2', name: 'Glue Compressor', enabled: true },
  { id: 'fx3', name: 'Saturator', enabled: false },
  { id: 'fx4', name: 'Reverb Hall', enabled: true },
  { id: 'fx5', name: 'Limiter', enabled: false },
]
