"use client"

import { useState } from "react"
import { Search, Folder, FolderOpen, FileAudio, Files, Blocks, Music2, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { FILE_TREE, type FileNode } from "./data"

const TABS = [
  { id: "files", label: "Files", icon: Files },
  { id: "plugins", label: "Plugins", icon: Blocks },
  { id: "sounds", label: "Sounds", icon: Music2 },
] as const

function TreeItem({ node, depth }: { node: FileNode; depth: number }) {
  const [open, setOpen] = useState(depth < 1)
  const hasChildren = !!node.children?.length

  return (
    <div>
      <button
        type="button"
        onClick={() => hasChildren && setOpen((o) => !o)}
        className="flex w-full items-center gap-1 rounded px-1 py-0.5 text-left text-[11px] text-zinc-400 transition-colors hover:bg-zinc-800/70 hover:text-zinc-200"
        style={{ paddingLeft: `${depth * 12 + 4}px` }}
      >
        {hasChildren ? (
          <ChevronRight className={cn("h-3 w-3 shrink-0 text-zinc-600 transition-transform", open && "rotate-90")} />
        ) : (
          <span className="w-3 shrink-0" />
        )}
        {hasChildren ? (
          open ? (
            <FolderOpen className="h-3.5 w-3.5 shrink-0 text-cyan-400/80" />
          ) : (
            <Folder className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
          )
        ) : (
          <FileAudio className="h-3.5 w-3.5 shrink-0 text-zinc-600" />
        )}
        <span className="truncate">{node.name}</span>
      </button>
      {hasChildren && open && (
        <div>
          {node.children!.map((child) => (
            <TreeItem key={child.name} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

export function BrowserSidebar() {
  const [active, setActive] = useState<(typeof TABS)[number]["id"]>("files")

  return (
    <aside className="flex h-full flex-col border-r border-zinc-800 bg-zinc-900">
      {/* Tabs */}
      <div className="flex border-b border-zinc-800">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActive(tab.id)}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 border-b-2 py-2 text-[11px] font-medium transition-colors",
              active === tab.id
                ? "border-cyan-400 text-cyan-400"
                : "border-transparent text-zinc-500 hover:text-zinc-300",
            )}
          >
            <tab.icon className="h-3.5 w-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="border-b border-zinc-800 p-2">
        <div className="flex items-center gap-1.5 rounded border border-zinc-800 bg-zinc-950 px-2 py-1">
          <Search className="h-3.5 w-3.5 text-zinc-600" />
          <input
            type="text"
            placeholder="Search library..."
            className="w-full bg-transparent text-[11px] text-zinc-300 placeholder:text-zinc-600 outline-none"
            aria-label="Search library"
          />
        </div>
      </div>

      {/* Tree */}
      <div className="min-h-0 flex-1 overflow-y-auto p-1.5">
        <p className="px-1 py-1 text-[9px] font-semibold uppercase tracking-[0.15em] text-zinc-600">
          {active}
        </p>
        {FILE_TREE.map((node) => (
          <TreeItem key={node.name} node={node} depth={0} />
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-zinc-800 px-2 py-1.5 text-[10px] text-zinc-600">
        128 items · 2.4 GB
      </div>
    </aside>
  )
}
