"use client"

import { cn } from "@/lib/utils"
import { TRACKS, type Track } from "./data"
import { Volume2, VolumeX, Headphones } from "lucide-react"

const TOTAL_UNITS = 18
const BARS = 9

function TrackHeader({
  track,
  selected,
  onSelect,
}: {
  track: Track
  selected: boolean
  onSelect: () => void
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex h-full w-44 shrink-0 flex-col justify-center gap-1 border-b border-r border-zinc-800 px-2 text-left transition-colors",
        selected ? "bg-zinc-800/80" : "bg-zinc-900 hover:bg-zinc-800/50",
      )}
    >
      <div className="flex items-center gap-1.5">
        <span className={cn("h-2.5 w-2.5 rounded-sm", track.color)} />
        <span className="truncate text-[11px] font-semibold text-zinc-200">{track.name}</span>
        <span className="ml-auto text-[8px] font-medium uppercase tracking-wider text-zinc-600">
          {track.type}
        </span>
      </div>
      <div className="flex items-center gap-1">
        {["M", "S"].map((b) => (
          <span
            key={b}
            className="flex h-4 w-4 items-center justify-center rounded-sm bg-zinc-800 text-[9px] font-bold text-zinc-500"
          >
            {b}
          </span>
        ))}
        <Headphones className="h-3 w-3 text-zinc-600" />
        <div className="ml-1 h-1 flex-1 overflow-hidden rounded-full bg-zinc-800">
          <div className={cn("h-full", track.color)} style={{ width: "70%" }} />
        </div>
      </div>
    </button>
  )
}

export function Timeline({
  selectedTrack,
  onSelectTrack,
}: {
  selectedTrack: string
  onSelectTrack: (id: string) => void
}) {
  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-zinc-950">
      {/* Ruler */}
      <div className="flex h-7 shrink-0 border-b border-zinc-800 bg-zinc-900">
        <div className="flex w-44 shrink-0 items-center border-r border-zinc-800 px-2 text-[9px] font-semibold uppercase tracking-[0.15em] text-zinc-600">
          Arrangement
        </div>
        <div className="relative flex flex-1">
          {Array.from({ length: BARS }).map((_, i) => (
            <div
              key={i}
              className="flex flex-1 items-center border-r border-zinc-800/60 px-1.5 font-mono text-[10px] text-zinc-600"
            >
              {i + 1}
            </div>
          ))}
        </div>
      </div>

      {/* Tracks + playhead */}
      <div className="relative min-h-0 flex-1 overflow-auto">
        <div className="relative grid h-full grid-rows-4">
          {TRACKS.map((track) => (
            <div key={track.id} className="flex border-b border-zinc-800/80">
              <TrackHeader
                track={track}
                selected={selectedTrack === track.id}
                onSelect={() => onSelectTrack(track.id)}
              />
              {/* Lane */}
              <div className="relative flex-1">
                {/* grid lines */}
                <div
                  className="pointer-events-none absolute inset-0 grid"
                  style={{ gridTemplateColumns: `repeat(${TOTAL_UNITS}, minmax(0, 1fr))` }}
                >
                  {Array.from({ length: TOTAL_UNITS }).map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "border-r",
                        (i + 1) % 2 === 0 ? "border-zinc-800/70" : "border-zinc-900",
                      )}
                    />
                  ))}
                </div>
                {/* clips */}
                <div
                  className="relative grid h-full items-center gap-0 p-1"
                  style={{ gridTemplateColumns: `repeat(${TOTAL_UNITS}, minmax(0, 1fr))` }}
                >
                  {track.clips.map((clip) => (
                    <div
                      key={clip.id}
                      style={{ gridColumn: `${clip.start} / span ${clip.span}` }}
                      className={cn(
                        "group flex h-[80%] flex-col overflow-hidden rounded-sm border text-[10px] shadow-sm",
                        track.color,
                        track.border,
                      )}
                    >
                      <span className="truncate px-1.5 pt-0.5 font-medium text-zinc-950/90">
                        {clip.label}
                      </span>
                      {/* fake waveform */}
                      <div className="flex flex-1 items-end gap-px overflow-hidden px-1 pb-0.5 opacity-60">
                        {Array.from({ length: clip.span * 6 }).map((_, i) => (
                          <span
                            key={i}
                            className="flex-1 rounded-sm bg-zinc-950/50"
                            style={{ height: `${Math.round(20 + Math.abs(Math.sin(i * 1.7) * 70))}%` }}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {/* Playhead */}
          <div
            className="pointer-events-none absolute bottom-0 top-0 z-10"
            style={{ left: "calc(11rem + 38%)" }}
          >
            <div className="relative h-full w-px bg-rose-500 shadow-[0_0_6px_theme(colors.rose.500)]">
              <div className="absolute -left-[3px] -top-0 h-1.5 w-[7px] bg-rose-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Status strip */}
      <div className="flex h-6 shrink-0 items-center gap-4 border-t border-zinc-800 bg-zinc-900 px-3 text-[10px] text-zinc-500">
        <span className="flex items-center gap-1">
          <Volume2 className="h-3 w-3" /> -6.2 dB
        </span>
        <span className="flex items-center gap-1">
          <VolumeX className="h-3 w-3" /> 0 muted
        </span>
        <span className="ml-auto font-mono">44.1 kHz · 24-bit · 128 samples</span>
      </div>
    </section>
  )
}
