"use client"

import { useState } from "react"
import { ChevronDown, Power, Plus, Disc3 } from "lucide-react"
import { cn } from "@/lib/utils"
import { INSERT_EFFECTS, TRACKS } from "./data"

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className={cn(
        "relative h-3.5 w-6 shrink-0 rounded-full transition-colors",
        on ? "bg-cyan-400" : "bg-zinc-700",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-2.5 w-2.5 rounded-full bg-zinc-950 transition-transform",
          on ? "translate-x-3" : "translate-x-0.5",
        )}
      />
    </button>
  )
}

function RoutingSelect({ label, value }: { label: string; value: string }) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-[9px] font-semibold uppercase tracking-wider text-zinc-600">{label}</span>
      <div className="flex items-center justify-between rounded border border-zinc-800 bg-zinc-950 px-2 py-1 text-[11px] text-zinc-300">
        <span className="truncate">{value}</span>
        <ChevronDown className="h-3 w-3 shrink-0 text-zinc-600" />
      </div>
    </label>
  )
}

function Knob({ label, value }: { label: string; value: number }) {
  // value 0..100 -> rotation -135..135
  const angle = -135 + (value / 100) * 270
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative h-10 w-10 rounded-full border border-zinc-700 bg-zinc-800">
        <div
          className="absolute left-1/2 top-1/2 h-3.5 w-0.5 origin-bottom -translate-x-1/2 -translate-y-full rounded-full bg-cyan-400"
          style={{ transform: `translate(-50%, -100%) rotate(${angle}deg)`, transformOrigin: "bottom center" }}
        />
      </div>
      <span className="text-[9px] font-medium uppercase tracking-wider text-zinc-500">{label}</span>
    </div>
  )
}

export function InspectorSidebar({ selectedTrack }: { selectedTrack: string }) {
  const [effects, setEffects] = useState(INSERT_EFFECTS)
  const track = TRACKS.find((t) => t.id === selectedTrack) ?? TRACKS[0]

  return (
    <aside className="flex h-full flex-col border-l border-zinc-800 bg-zinc-900">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-zinc-800 px-3 py-2.5">
        <span className={cn("h-3 w-3 rounded-sm", track.color)} />
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold text-zinc-200">{track.name}</p>
          <p className="text-[9px] uppercase tracking-wider text-zinc-600">{track.type} Track</p>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {/* Routing */}
        <section className="border-b border-zinc-800 p-3">
          <h3 className="mb-2 text-[9px] font-semibold uppercase tracking-[0.15em] text-zinc-500">
            Routing
          </h3>
          <div className="flex flex-col gap-2">
            <RoutingSelect label="Input" value="Ext. In 1/2" />
            <RoutingSelect label="Output" value="Master" />
          </div>
        </section>

        {/* Insert Effects */}
        <section className="border-b border-zinc-800 p-3">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-[9px] font-semibold uppercase tracking-[0.15em] text-zinc-500">
              Insert Effects
            </h3>
            <button
              type="button"
              className="flex h-4 w-4 items-center justify-center rounded text-zinc-500 hover:bg-zinc-800 hover:text-cyan-400"
              aria-label="Add effect"
            >
              <Plus className="h-3 w-3" />
            </button>
          </div>
          <div className="flex flex-col gap-1">
            {effects.map((fx) => (
              <div
                key={fx.id}
                className={cn(
                  "flex items-center gap-2 rounded border px-2 py-1.5 transition-colors",
                  fx.enabled
                    ? "border-zinc-700 bg-zinc-800/60"
                    : "border-zinc-800 bg-zinc-950/40",
                )}
              >
                <Power className={cn("h-3 w-3 shrink-0", fx.enabled ? "text-cyan-400" : "text-zinc-600")} />
                <span className={cn("flex-1 truncate text-[11px]", fx.enabled ? "text-zinc-200" : "text-zinc-600")}>
                  {fx.name}
                </span>
                <Toggle
                  on={fx.enabled}
                  onClick={() =>
                    setEffects((prev) =>
                      prev.map((e) => (e.id === fx.id ? { ...e, enabled: !e.enabled } : e)),
                    )
                  }
                />
              </div>
            ))}
          </div>
        </section>

        {/* Volume / Pan */}
        <section className="p-3">
          <h3 className="mb-3 text-[9px] font-semibold uppercase tracking-[0.15em] text-zinc-500">
            Mixer
          </h3>
          <div className="mb-3 flex items-center justify-around">
            <Knob label="Pan" value={50} />
            <Knob label="Send A" value={30} />
            <Knob label="Send B" value={15} />
          </div>

          {/* Volume slider */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between text-[10px]">
              <span className="font-medium uppercase tracking-wider text-zinc-500">Volume</span>
              <span className="font-mono text-cyan-400">-6.2 dB</span>
            </div>
            <div className="relative h-2 rounded-full bg-zinc-800">
              <div className="absolute inset-y-0 left-0 w-[68%] rounded-full bg-gradient-to-r from-cyan-500/60 to-cyan-400" />
              <div className="absolute top-1/2 h-4 w-2 -translate-y-1/2 rounded-sm border border-cyan-300 bg-zinc-200 shadow" style={{ left: "calc(68% - 4px)" }} />
            </div>
          </div>

          {/* Pan slider */}
          <div className="mt-3 flex flex-col gap-1.5">
            <div className="flex items-center justify-between text-[10px]">
              <span className="font-medium uppercase tracking-wider text-zinc-500">Pan</span>
              <span className="font-mono text-zinc-400">C</span>
            </div>
            <div className="relative h-2 rounded-full bg-zinc-800">
              <div className="absolute left-1/2 top-1/2 h-3 w-px -translate-y-1/2 bg-zinc-600" />
              <div className="absolute top-1/2 h-4 w-2 -translate-x-1/2 -translate-y-1/2 rounded-sm border border-zinc-500 bg-zinc-300 shadow" style={{ left: "50%" }} />
            </div>
          </div>
        </section>
      </div>

      {/* Footer meters */}
      <div className="flex items-center gap-2 border-t border-zinc-800 px-3 py-2">
        <Disc3 className="h-3.5 w-3.5 animate-spin text-zinc-600" style={{ animationDuration: "4s" }} />
        <div className="flex flex-1 gap-1">
          {[0, 1].map((ch) => (
            <div key={ch} className="h-1.5 flex-1 overflow-hidden rounded-full bg-zinc-800">
              <div className="h-full bg-gradient-to-r from-cyan-400 to-amber-400" style={{ width: ch ? "55%" : "72%" }} />
            </div>
          ))}
        </div>
        <span className="font-mono text-[9px] text-zinc-500">L/R</span>
      </div>
    </aside>
  )
}
