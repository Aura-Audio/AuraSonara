"use client"

import { useState } from "react"
import { Play, Square, Circle, SkipBack, Repeat, Cpu, MemoryStick } from "lucide-react"
import { cn } from "@/lib/utils"

function Meter({ label, value, icon: Icon }: { label: string; value: number; icon: typeof Cpu }) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="h-3.5 w-3.5 text-zinc-500" />
      <span className="text-[10px] font-medium uppercase tracking-wider text-zinc-500">{label}</span>
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-zinc-800">
        <div
          className={cn(
            "h-full rounded-full",
            value > 80 ? "bg-rose-500" : value > 50 ? "bg-amber-400" : "bg-cyan-400",
          )}
          style={{ width: `${value}%` }}
        />
      </div>
      <span className="w-7 text-right font-mono text-[10px] text-zinc-400">{value}%</span>
    </div>
  )
}

export function TransportBar() {
  const [playing, setPlaying] = useState(false)
  const [recording, setRecording] = useState(false)
  const [loop, setLoop] = useState(true)
  const [bpm, setBpm] = useState(124)

  return (
    <header className="flex h-12 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-3">
      {/* Left: brand + transport */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 pr-3">
          <div className="h-4 w-4 rounded-sm bg-cyan-400 shadow-[0_0_8px_theme(colors.cyan.400)]" />
          <span className="text-xs font-semibold tracking-tight text-zinc-200">RESONANCE</span>
        </div>

        <div className="flex items-center gap-1 border-l border-zinc-800 pl-3">
          <button
            type="button"
            className="flex h-7 w-7 items-center justify-center rounded text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-zinc-200"
            aria-label="Return to start"
          >
            <SkipBack className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            aria-label={playing ? "Stop" : "Play"}
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded transition-colors",
              playing
                ? "bg-cyan-400 text-zinc-950 shadow-[0_0_10px_theme(colors.cyan.400/0.6)]"
                : "text-zinc-300 hover:bg-zinc-800",
            )}
          >
            <Play className="h-3.5 w-3.5 fill-current" />
          </button>
          <button
            type="button"
            onClick={() => setPlaying(false)}
            aria-label="Stop"
            className="flex h-7 w-7 items-center justify-center rounded text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-zinc-200"
          >
            <Square className="h-3.5 w-3.5 fill-current" />
          </button>
          <button
            type="button"
            onClick={() => setRecording((r) => !r)}
            aria-label="Record"
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded transition-colors",
              recording
                ? "bg-rose-500/20 text-rose-500"
                : "text-zinc-400 hover:bg-zinc-800 hover:text-rose-400",
            )}
          >
            <Circle className={cn("h-3.5 w-3.5", recording && "fill-current animate-pulse")} />
          </button>
          <button
            type="button"
            onClick={() => setLoop((l) => !l)}
            aria-label="Toggle loop"
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded transition-colors",
              loop ? "text-cyan-400" : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200",
            )}
          >
            <Repeat className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Center: timecode + bpm */}
      <div className="flex items-center gap-3">
        <div className="flex flex-col items-center rounded border border-zinc-800 bg-zinc-950 px-3 py-0.5">
          <span className="font-mono text-base leading-tight tabular-nums tracking-widest text-cyan-400">
            01:24:03:12
          </span>
          <span className="text-[8px] uppercase tracking-[0.2em] text-zinc-600">bars · beats</span>
        </div>

        <div className="flex items-center gap-1.5 rounded border border-zinc-800 bg-zinc-950 px-2 py-1">
          <input
            type="number"
            value={bpm}
            onChange={(e) => setBpm(Number(e.target.value))}
            className="w-10 bg-transparent text-right font-mono text-sm text-zinc-200 outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
            aria-label="Tempo in beats per minute"
          />
          <span className="text-[9px] font-medium uppercase tracking-wider text-zinc-500">bpm</span>
        </div>

        <div className="flex flex-col items-center rounded border border-zinc-800 bg-zinc-950 px-2.5 py-0.5">
          <span className="font-mono text-sm leading-tight text-zinc-300">4 / 4</span>
          <span className="text-[8px] uppercase tracking-[0.2em] text-zinc-600">sig</span>
        </div>
      </div>

      {/* Right: meters */}
      <div className="flex items-center gap-4">
        <Meter label="CPU" value={42} icon={Cpu} />
        <Meter label="RAM" value={67} icon={MemoryStick} />
      </div>
    </header>
  )
}
