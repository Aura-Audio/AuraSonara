"use client"

import { useState } from "react"
import { TransportBar } from "@/components/daw/transport-bar"
import { BrowserSidebar } from "@/components/daw/browser-sidebar"
import { Timeline } from "@/components/daw/timeline"
import { InspectorSidebar } from "@/components/daw/inspector-sidebar"

export default function Page() {
  const [selectedTrack, setSelectedTrack] = useState("t1")

  return (
    <div
      className="grid h-screen w-screen overflow-hidden bg-zinc-950 text-zinc-200"
      style={{
        gridTemplateColumns: "250px minmax(0, 1fr) 250px",
        gridTemplateRows: "auto minmax(0, 1fr)",
        gridTemplateAreas: `
          "transport transport transport"
          "browser   timeline  inspector"
        `,
      }}
    >
      <div style={{ gridArea: "transport" }}>
        <TransportBar />
      </div>
      <div style={{ gridArea: "browser" }} className="min-h-0">
        <BrowserSidebar />
      </div>
      <div style={{ gridArea: "timeline" }} className="flex min-h-0 min-w-0">
        <Timeline selectedTrack={selectedTrack} onSelectTrack={setSelectedTrack} />
      </div>
      <div style={{ gridArea: "inspector" }} className="min-h-0">
        <InspectorSidebar selectedTrack={selectedTrack} />
      </div>
    </div>
  )
}
